import java.util.Scanner;

public class Main {
    static int amount;
    public static void main(String[] args) {
        System.out.println("\t\tWelcome to ATM Machine");
        System.out.println("\t ----------------------------");
        System.out.println();
        System.out.println();
        System.out.println("Select an Option");
        System.out.println("1.WithDrawl\n2.Deposit\n3.Check Balance");

        User_BankAccount user=new User_BankAccount();

        Scanner input=new Scanner(System.in);
        while(true){
            System.out.println();
            System.out.print("Enter an Option : ");
            int option=input.nextInt();
            if(option==1 ){
                System.out.print("Enter the amount to Withdraw : ");
                amount=input.nextInt();
                user.withdraw(amount);

                System.out.println();
                System.out.println("Press 3 to Check Balance\nPress 0 to Exit");
                while(true){
                    System.out.print("Select an Option : ");
                    int option1=input.nextInt();
                    if(option1==3){
                        user.checkBalance();
                        break;
                    }
                    if(option1==0){
                        System.out.println("Exit");
                        break;
                    }
                    else{
                        System.out.println();
                        System.out.println("Please Select an option either 3 or 0");
                    }
                }
                break;
            }
            else if(option==2){
                System.out.print("Enter the amount to Deposit : ");
                amount=input.nextInt();
                user.deposit(amount);

                System.out.println();
                System.out.println("Press 3 to Check Balance\nPress 0 to Exit");
                while(true){
                    System.out.print("Select an Option : ");
                    int option1=input.nextInt();
                    if(option1==3){
                        user.checkBalance();
                        break;
                    }
                    if(option1==0){
                        System.out.println("Exit");
                        break;
                    }
                    else{
                        System.out.println();
                        System.out.println("Please Select an option either 3 or 0");
                    }
                }
                break;
            }
            else if(option==3){
                user.checkBalance();
                break;
            }
            else{
                System.out.println();
                System.out.println("Select an Option from the list");
                System.out.println("1.WithDrawl\n2.Deposit\n3.Check Balance");
            }
        }
    }
}