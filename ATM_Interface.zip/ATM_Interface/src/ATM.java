public interface ATM {

    void withdraw(int amount);
    void deposit(int amount);
    void checkBalance();

}
