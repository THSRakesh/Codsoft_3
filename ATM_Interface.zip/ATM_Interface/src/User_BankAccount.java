
public class User_BankAccount implements ATM{
    static int accountBalance=10000;

    public void withdraw(int amount){
        if(accountBalance<amount){
            System.out.println("Insufficient Balance");
            throw new IllegalArgumentException("WithDrawl amount is More Than Account Balance");
        }
        else {
            accountBalance = accountBalance - amount;
            System.out.println();
            System.out.println("Transaction is Success! ");
            System.out.println("Amount is Debited from your Account");
        }
    }
    public void deposit(int amount){
        accountBalance+=amount;
        System.out.println();
        System.out.println("Transaction is Success! ");
        System.out.println("Amount is Credited into your Account");
    }
    public void checkBalance(){
        System.out.println();
        System.out.println("Account Balance : "+accountBalance);
    }
}
